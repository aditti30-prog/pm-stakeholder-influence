<!--
============================================================
HOW TO USE THIS FILE
============================================================

This is a Claude Skill — a structured knowledge file that
makes Claude an expert stakeholder influence coach.

SETUP (takes 30 seconds):
1. Put this SKILL.md file inside a folder named
   "pm-stakeholder-influence"
2. Zip that folder
3. Open claude.ai → Settings → Customize → Skills
4. Click "+" → "Create skill" → Upload the zip
5. Toggle it on. Done.

The skill fires automatically when you describe a
stakeholder situation. Try:
   - "My VP is blocking my roadmap item. Help me prepare."
   - "I need to deliver bad news to my CEO about a missed date."
   - "Two execs want incompatible things and I'm stuck."
   - "A peer PM won't prioritize my dependency. What do I do?"
   - "Someone took credit for my work. How do I handle this?"

Claude will diagnose your situation, identify the exec
archetype, recommend plays, and script your talking points.

Works on: Claude.ai (Free/Pro/Max/Team/Enterprise),
          Claude Code, Claude Cowork.

Created by Aditi — Staff PM, Digital Commerce & Payments.
============================================================
-->

---
name: pm-stakeholder-influence
description: Use this skill for any stakeholder influence, political navigation, or difficult conversation work — exec disagreements, scope battles, roadmap vetoes, trust deficits, credit erosion, decision reversals, misaligned stakeholders, delivering bad news, saying no to leadership, peer dependency negotiation, or navigating being the exec receiving influence. Trigger on: stakeholder conflict, difficult conversation, exec pushback, blocked roadmap, scope creep, trust problem, credit issue, pre-wiring, escalation, decision reversal, political navigation, influence without authority, navigate stakeholder, "how do I handle", or any request involving managing up/across/down in a product org — even if they don't use those exact terms. Also trigger for "my VP wants", "exec is blocking", "two stakeholders disagree", "how do I say no", "someone took credit", "how do I push back", or "I need to reverse a decision".
---

# PM Stakeholder Influence Playbook

Situation diagnosis. Exec archetypes. Play selection.

Written from the perspective of a CPO who has been a Jr PM, PM, Senior PM, Group PM, Director, VP, and CPO. Every situation in this playbook is one I've lived or watched someone else navigate badly.

## How to Use This Playbook

Run these steps in order before any difficult stakeholder conversation.

1. **Diagnose the situation** (Section 1) — identify the primary situation type using diagnostic questions
2. **Identify the exec archetype** if an exec is involved (Section 2)
3. **Clarify your objective** (Section 3)
4. **Select your play** (Section 4) — single play for simple situations, combined plays for complex ones (Section 4B)
5. **Anticipate the counter** (Section 5)
6. **Know when to escalate or exit** (Section 6)
7. **If you ARE the exec** — use the bidirectional lens (Section 7)

---

## Section 1 — Situation Typing

Before any play, diagnose the situation. Most PM-stakeholder problems fall into one of nine types. Most situations are combinations — identify the primary type first.

| # | Situation | Core Dynamic |
|---|-----------|--------------|
| S1 | Scope expansion | Stakeholder keeps adding to committed work |
| S2 | Solution-first exec | They've decided the answer before you've diagnosed the problem |
| S3 | Roadmap veto | Your prioritized item gets blocked or deprioritized by leadership |
| S4 | Bad news delivery | You need to tell an exec something they won't want to hear |
| S5 | Trust deficit | Stakeholder doesn't believe you, your data, or your judgment |
| S6 | Credit erosion | Your work is being attributed to someone else or absorbed by a team |
| S7 | Misaligned co-stakeholders | Two execs want incompatible things and you're in the middle |
| S8 | The 'no' you need to reverse | You received a decision you believe is wrong and need to reopen it |
| S9 | Peer dependency deadlock | A peer PM, design lead, or engineering lead controls something you need and won't prioritize it |

### Diagnostic Questions Per Situation

Don't just label the situation — interrogate it. The wrong diagnosis leads to the wrong play.

**S1 — Scope expansion**: Is the stakeholder adding scope because they're insecure about their own delivery, or because requirements genuinely evolved? The tell: "while you're at it" = insecurity-driven. "I just learned X from customer Y" = information-driven. The play changes: insecurity-driven scope needs trade-off framing (Play 1). Information-driven scope might be legitimate and needs evaluation, not resistance.

**S2 — Solution-first exec**: Are they actually wrong, or are they directionally right with poor specificity? Many solution-first execs have strong pattern recognition. If their instinct is roughly correct, your redirect should refine, not replace. If they're genuinely wrong, you need data they haven't seen.

**S3 — Roadmap veto**: Is the veto about your specific item, or about their team's capacity? Ask: "If resources weren't a constraint, would you support this?" If yes, it's a resourcing negotiation (Play 8). If no, it's a strategic disagreement (Play 9).

**S4 — Bad news delivery**: How much of the problem is yours to own? Partial ownership builds trust. Zero ownership reads as blame-shifting. Before walking in, identify the 20% that was in your control, even if 80% was external.

**S5 — Trust deficit**: Is this inherited (they didn't trust your predecessor) or earned (you missed something)? Inherited trust deficits need consistency over time (Play 4). Earned trust deficits need explicit acknowledgment of the miss first, then consistency.

**S6 — Credit erosion**: Is this person doing it consciously or unconsciously? Conscious credit absorbers won't change behavior regardless of confrontation — your only move is structural visibility (Play 5). Unconscious credit absorbers sometimes respond to a private, specific conversation: "In the last review, the framing suggested X originated from your team. I want to make sure the attribution is clear going forward."

**S7 — Misaligned co-stakeholders**: Do both execs know they're in conflict, or does each think you're aligned with them? If they don't know, surfacing the conflict IS the move (Play 6). If they know and are using you as a proxy war, escalate immediately — you cannot resolve a fight they won't have directly.

**S8 — Decision reversal**: Do you have genuinely new information, or are you relitigating with better rhetoric? If it's the same information repackaged, don't attempt the reversal. You'll burn credibility. New information includes: quantified cost data that wasn't in the room, customer evidence that contradicts the assumption, or a strategic priority conflict they didn't see.

**S9 — Peer dependency deadlock**: Is this a prioritization disagreement or a relationship problem? If your peer agrees your request matters but can't fit it: negotiate scope, timeline, or escalate together to a shared leader. If your peer doesn't believe your request matters: you have a framing problem — restate the ask in terms of their metrics, not yours. If your peer is politically blocking you: that's a relationship problem requiring direct conversation first, escalation second.

---

## Section 2 — Exec Archetypes

Every difficult exec has a fear or incentive underneath their behavior. Name it before you strategize.

### The Scope Creeper
| Attribute | Detail |
|-----------|--------|
| Behavior | Adds requirements mid-sprint, says "while you're at it," expands definition of done |
| Underlying driver | Fear of missing something important. Often insecure about their own delivery |
| What they respect | Structured trade-off framing. Options, not pushback |
| What triggers them | Feeling dismissed or told "no" directly |

### The Solution-First Thinker
| Attribute | Detail |
|-----------|--------|
| Behavior | Comes in with "we should build X" before you've had a chance to diagnose |
| Underlying driver | Impatience. Often high agency, used to being right. May have been a builder |
| What they respect | Speed of response + acknowledgment of their instinct before redirecting |
| What triggers them | Feeling slowed down. Being academically walked through a framework |

### The Trust Withholder
| Attribute | Detail |
|-----------|--------|
| Behavior | Questions your data, your methodology, your judgment. Wants to re-examine everything |
| Underlying driver | Past disappointment — either with you specifically, or a PM before you |
| What they respect | Proactive transparency. Showing your work before being asked |
| What triggers them | Defensiveness. Feeling like information is being managed |

### The Invisible Decision Maker
| Attribute | Detail |
|-----------|--------|
| Behavior | Quiet in meetings, then reverses decisions afterward through a back-channel |
| Underlying driver | Conflict avoidance. Prefers to influence through proxies |
| What they respect | Private conversations before group settings. Being consulted, not just informed |
| What triggers them | Being put on the spot in front of others. Public disagreement |

### The Credit Absorber
| Attribute | Detail |
|-----------|--------|
| Behavior | Presents your work as their idea, takes ownership in exec forums, under-attributes |
| Underlying driver | Insecurity + competition for visibility upward |
| What they respect | Nothing you do will change this archetype. Your strategy is visibility management |
| What triggers them | Direct confrontation about attribution — it goes underground |

### The Scope Blocker
| Attribute | Detail |
|-----------|--------|
| Behavior | Blocks your roadmap item, usually with "not the right time" or resource objections |
| Underlying driver | Usually protecting their own team's capacity, or skeptical of your bet |
| What they respect | Business case tied to their metrics, not yours |
| What triggers them | Feeling like you're making them look bad or adding to their team's burden |

### The Chaos Agent
| Attribute | Detail |
|-----------|--------|
| Behavior | Changes priorities frequently, contradicts past decisions, reacts to the last conversation they had |
| Underlying driver | Externally reactive — responds to whoever had access to them most recently |
| What they respect | Documented decisions. Written confirmation. Short feedback loops |
| What triggers them | Ambiguity. They fill it unpredictably |

### The Brilliant Jerk
| Attribute | Detail |
|-----------|--------|
| Behavior | Smart, often right, dismissive, will cut you off or publicly minimize your work |
| Underlying driver | High standards, low patience, often doesn't realize the impact |
| What they respect | Directness. Intellectual rigor. Being challenged by someone who knows their stuff |
| What triggers them | Hedging. Over-qualification. "I think maybe possibly..." |

---

## Section 3 — Clarify Your Objective

Before selecting a play, answer these three questions. Without them, you'll optimize for the wrong outcome.

**Q1: What do I actually need from this interaction?**
- A decision reversed
- A decision made
- Buy-in to proceed
- Information I don't have
- Conflict resolved
- Just to be heard

**Q2: What's the relationship cost I'm willing to pay?**
- Zero — I need this relationship intact long-term
- Some — I can afford tension if I win the point
- High — I'm willing to escalate or go around them

**Q3: What does winning look like in 6 months, not today?**
Distinguish short-term wins that create long-term damage from positions worth fighting for.

---

## Section 4 — The Plays

### PLAY 1 — The Structured Trade-Off [S1, S3]

**Use when:** Stakeholder is adding scope or blocking your item.

**How it works:** Never say no directly. Present the trade-off explicitly.

"I can add [their request]. To do that in this sprint, I'd need to move [X] or [Y]. Which would you like me to deprioritize?"

Force the trade-off decision back to them. Most scope creep stops when the stakeholder has to own what they're cutting.

If they say "do both": "I want to be transparent — if we try to do both, [specific risk]. I'd rather tell you now than miss the date. Which matters more?"

- **Jr PM:** You will feel like you're being difficult. You're not. You're protecting the team.
- **Senior PM:** Document this conversation in writing immediately after.
- **CPO:** If this pattern repeats 3+ times, it's a process problem not a person problem. Install a change-request mechanism.

---

### PLAY 2 — The Acknowledge-Then-Redirect [S2]

**Use when:** Exec comes in with a pre-decided solution.

**How it works:** Acknowledge the instinct (it's usually directionally right). Then redirect to the problem.

"That's interesting — I can see why you'd go there. Can I share what I'm seeing in the data first? I want to make sure we're solving the root problem, not a symptom."

Then present the problem diagnosis. Let them arrive at the solution themselves if possible.

Never: "Actually, that's not the right solution." Even if it isn't.
Always: Make them feel like their instinct was the starting point, not the thing you're overriding.

- **Jr PM:** This feels manipulative at first. It isn't. You're doing the actual PM work.
- **Staff / Principal PM:** Push the redirect harder. At your level, soft redirects read as agreement.

---

### PLAY 3 — The Pre-Wiring [S2, S3, S8]

**Use when:** You have a contentious decision or roadmap item coming to a group.

**How it works:** Never let a consequential decision be made cold in a room.

"Before Thursday's review, I wanted to walk you through my thinking on [item] and get your read."

1. Identify who has veto power (usually 1-2 people)
2. Have a 1:1 with each before the group session
3. Surface objections privately — they're easier to address
4. Walk in knowing where each person stands
5. Use the meeting to confirm, not debate

The goal: No surprises in the room. For you or for them.

- **Jr PM:** You probably don't have access to do full pre-wiring. Start with your direct manager. Get them pre-sold before the exec.
- **CPO:** If your team isn't pre-wiring, they're leaving decisions to chance. Build this into your team's operating rhythm.

---

### PLAY 4 — The Transparency Offensive [S5]

**Use when:** A stakeholder doesn't trust your judgment or data.

**How it works:** Don't wait to be asked. Over-share proactively.

"Here's what I know, here's what I'm assuming, and here's where I'm least confident. I'd rather you poke holes now."

Send a weekly 5-bullet update before they ask. Show your assumptions before presenting your conclusion. Name your uncertainties explicitly.

Trust is rebuilt through consistency over time, not through a single good presentation.

What not to do: Defend your methodology when challenged. It reads as fragile. Instead say: "That's a fair challenge — let me check that and come back to you."

- **Jr PM:** This costs you nothing and pays off significantly. Just do it.
- **Director+:** If you have a trust deficit with your CEO, you have at most one quarter to close it or start planning your next move.

---

### PLAY 5 — The Visibility Architecture [S6]

**Use when:** Your work is being absorbed or under-attributed.

**How it works:** You cannot fight credit battles directly. Build structural visibility instead.

- Send written summaries of decisions to a wider distribution than necessary
- CC your manager on key decisions with explicit attribution ("As [you] proposed...")
- Present your own work in cross-functional forums — don't let intermediaries represent it
- Create artifacts (PRDs, strategy docs, memos) that have your name on them and live in shared systems

What not to do: Confront the credit absorber directly unless you have clear evidence and strong political capital. It almost always backfires.

- **Jr PM:** Start a work log. Date-stamped record of decisions, proposals, initiatives. You'll need it.
- **Staff PM:** Your visibility strategy should be proactive, not reactive. Waiting until credit is lost is too late.

---

### PLAY 6 — The Dual-Exec Alignment [S7]

**Use when:** Two stakeholders want incompatible things and you're in the middle.

**How it works:** Do not try to resolve this yourself. Escalate the conflict, not the decision.

"I want to make sure I'm prioritizing correctly. [Exec A] has asked for [X] and [Exec B] has asked for [Y] — they're in conflict and I can only do one well. Can I get 30 minutes with both of you to align?"

Get them in a room together. Make the conflict explicit. Let them resolve it. Your job is to make the decision-making surface visible, not to absorb incompatible demands.

What not to do: Pick one exec's side without explicit escalation. You will lose the other one.
What not to do: Try to split the difference and deliver a watered-down version of both. Nobody's happy.

- **Jr PM:** This situation will feel like your failure. It's not. It's an organizational failure that landed on you.
- **CPO:** If this pattern is recurring across your PM team, you have a strategy clarity problem at the top.

---

### PLAY 7 — The Bad News Protocol [S4]

**Use when:** You need to tell an exec something they don't want to hear.

**How it works:** Structure, speed, and ownership.

"We're going to miss the Q3 launch date by 3 weeks. The main cause was [X]. I own [part of it]. I have three options: [A, B, C]. I recommend B because [reason]. Do you want to talk through the trade-offs?"

1. Lead with the headline — don't build up to it
2. State the impact — be specific, don't soften
3. Own what's yours — even partial ownership builds trust
4. Present options — never just a problem, always options
5. Recommend one — don't make them do the thinking

What not to do: Bury it in a status update. Deliver bad news early and directly.
What not to do: Over-apologize. One clear acknowledgment of ownership is enough.

- **Jr PM:** You will want to soften this. Don't. Soft bad news reads as a lack of judgment.
- **Senior PM:** The speed of bad news delivery is itself a signal. Fast = trustworthy. Slow = managing information.

---

### PLAY 8 — The Principled No [S1, S3]

**Use when:** You need to decline a request from someone with more power.

**How it works:** Never say no to the person. Say no to the trade-off.

"I want to help you get [their goal]. If I take this on, here's what I'd need to stop or delay: [list]. If that's the right trade-off, I'm in. If not, let's figure out another path."

Four components of a sustainable no:
1. Acknowledge what they're trying to achieve
2. Show you understand why it matters to them
3. Name the cost explicitly
4. Offer a path forward (even if it's "not now, but in Q2")

What not to say: "I don't have bandwidth." It sounds like a capacity excuse, not a prioritization judgment.
What to say instead: "I don't think this is the highest-leverage use of our capacity right now, and here's why."

- **Jr PM:** You are allowed to say no. It will feel scary. Do it with a trade-off frame, not a flat refusal.
- **CPO:** A PM who can't say no is a feature factory. A PM who says no too often is uncoachable. The skill is knowing which battles to fight.

---

### PLAY 9 — The Decision Reversal [S8]

**Use when:** You received a decision you believe is wrong and need to reopen it.

**How it works:** You have one shot. Use it carefully.

"I want to respect the decision you made, and I also think I have some information that might change the calculus. Can I have 30 minutes to share it? If after that you still want to proceed as planned, I'll execute fully."

Prerequisites before attempting:
- You have new information they didn't have when they decided, OR
- You can show the decision conflicts with a stated strategic priority, OR
- The cost of the decision is now quantifiable and significant

Request a 30-minute conversation. Do not relitigate in email.

In the meeting: new information first, impact second, ask third. End with a clear ask: "I'd like to [specific reversal]" — not "I'm just not sure about this."

What not to do: Go around them to their manager without having this conversation first.
What not to do: Attempt this more than once per decision. If they hear you and still say no, that's their call.

- **Jr PM:** Pick this battle carefully. A failed reversal attempt spent on a low-stakes item costs credibility.
- **Staff+:** At your level, this conversation is expected. Not having it when you disagree is a signal of weak conviction.

---

### PLAY 10 — The Peer Negotiation [S9]

**Use when:** A peer (PM, Design Lead, Engineering Lead) controls a dependency you need and won't prioritize it, or disagrees with your direction on a shared surface.

**How it works:** Peers have no formal obligation to help you. You're negotiating, not delegating.

**Step 1 — Reframe in their language.** Don't pitch your roadmap item. Pitch the impact on their metrics.

"I know your team is focused on reducing churn this quarter. The integration I'm proposing directly feeds that — here's the data showing [X% of churn tickets] trace back to this gap."

**Step 2 — Propose a deal, not an ask.**

"If your team can give me [specific resource/time], I can [specific thing that helps them]. I've already scoped it to [minimal version] so it's [X] story points, not the full [Y]."

**Step 3 — If they still won't move, escalate together.**

"We're stuck on prioritization between [your item] and [their item]. Can we bring this to [shared leader] together so we're not making this call in a vacuum?"

What not to do: Go to their manager without telling them. Peer trust, once broken, is nearly impossible to rebuild.
What not to do: Frame it as "I need you to do this for me." Frame it as a shared problem.

The asymmetry to understand: You own the outcome. They own the resource. Neither of you has authority over the other. The only currency is mutual benefit and escalation rights.

- **Jr PM:** Start by building the relationship before you need something. Offer help on their priorities first. The ask comes easier when there's a deposit in the trust account.
- **Senior PM:** If you're regularly blocked by peers, the problem might be that your requests aren't tied to shared outcomes. Reframe before escalating.
- **Staff+:** At your level, peer deadlocks often signal an organizational design problem — shared OKRs, unclear ownership boundaries, or missing platform investment. Name the structural issue, don't just solve the instance.

---

## Section 4B — Combined Plays

Most real situations require more than one play. The playbook's power is in combinations. Here are the most common stacks, with worked examples.

### Combination 1: Pre-Wire + Principled No [S3 + Scope Blocker archetype]

**Scenario:** Your VP of Engineering is going to block your Q2 roadmap item at Thursday's product review. You know because they've signaled "not the right time" in a Slack thread.

**Sequence:**
1. **Play 3 (Pre-Wire)** — Monday: 1:1 with VP Eng. Don't pitch your item. Ask: "What's your biggest concern about Q2 capacity?" Listen. Map their constraints.
2. **Play 3 (Pre-Wire)** — Tuesday: 1:1 with your CPO or shared leader. Share what you heard from VP Eng. Get their read. Pre-align on your fallback.
3. **Play 8 (Principled No)** — Thursday in the room: "I hear the capacity concern. If we scope [item] to Phase 1 only — [specific reduced scope] — it's [X] fewer story points and doesn't touch [their team's critical path]. The trade-off of not doing it: [quantified cost]. Is that a trade-off we want to make?"

**Why this works:** By Thursday, VP Eng has been heard (not ambushed), your leader is pre-aligned, and you've reduced the ask to something defensible.

### Combination 2: Transparency Offensive + Acknowledge-Redirect [S5 + Trust Withholder archetype]

**Scenario:** Your CEO doesn't trust your product judgment after a missed launch. They've started coming to standups and suggesting solutions directly.

**Sequence:**
1. **Play 4 (Transparency Offensive)** — Week 1-4: Send a Friday update every week. Five bullets: what shipped, what's at risk, what you're deciding next week, what you're least confident about, what you need from them. Don't wait to be asked.
2. **Play 2 (Acknowledge-Redirect)** — In standup when they suggest a solution: "That's a good instinct — it's adjacent to something we're seeing in the data. Can I show you what the user research is pointing to? I think we can get a better version of what you're after."
3. **Play 4 (Transparency Offensive)** — After standup: Send a follow-up summarizing the conversation and what you're going to investigate. Close the loop before they have to ask.

**Why this works:** The transparency cadence rebuilds trust structurally. The redirect in the room preserves their dignity while keeping you in the driver's seat. The follow-up proves reliability.

### Combination 3: Dual-Exec Alignment + Pre-Wire + Bad News Protocol [S7 + Chaos Agent archetype]

**Scenario:** Your CRO wants a customer-specific feature. Your CTO wants platform investment. Both told you this is the priority. Your CRO is a Chaos Agent who will change their mind if challenged in a group.

**Sequence:**
1. **Play 3 (Pre-Wire)** — 1:1 with CRO: "I want to make sure I understand your ask. You need [specific outcome] for [customer]. Is that right? And if I can deliver that outcome a different way, are you open to it?" Get it in writing (Slack confirmation).
2. **Play 3 (Pre-Wire)** — 1:1 with CTO: Same conversation. Document.
3. **Play 6 (Dual-Exec Alignment)** — Bring both into a room: "I have two asks that are in conflict. [CRO ask] and [CTO ask]. I can do one well this quarter. I've documented both positions. Which one are we prioritizing?"
4. **Play 7 (Bad News Protocol)** — To the exec who loses: "I know this isn't the outcome you wanted. Here's my plan to address [their item] in Q3, and here's what I can do in Q2 as a partial interim measure."

**Why this works:** The pre-wiring with the Chaos Agent locks down their position before the group meeting. Written confirmation prevents post-meeting reversals. The bad news protocol with the losing exec preserves the relationship.

---

## Section 5 — Anticipate the Counter

For each play, prepare for these common responses before you walk into the room.

| Their Move | Your Response |
|-----------|--------------|
| "Just make it work" | "I want to. Help me understand what I can take off the plate to make room." |
| "That's not my problem" | "You're right, it shouldn't be. I'm bringing it to you because the decision sits at your level." |
| "I thought you had this handled" | "I did, until [specific event]. I'm here because I want to solve it, not just report it." |
| "Can't you just figure it out?" | "I've figured out three options. I need your call on which one to execute." |
| "We've already decided this" | "I know. I have new information I don't think was in the room when that call was made." |
| "Are you pushing back on me?" | "I'm giving you my honest assessment. I'd rather tell you now than deliver a result you didn't want." |
| "I'll just do it myself" | "I respect that. Can I share what I've learned so you have the full picture before you start?" |
| "Let's just test both" | "Happy to, if we can agree on the success criteria upfront. What metric tells us which one won?" |
| "You're overthinking this" | "Possibly. Here's the one thing I'd regret not flagging: [biggest risk]. If you're comfortable with that, I'll move fast." |

---

## Section 6 — Escalation and Exit Criteria

### When to Escalate Over Someone's Head

- The conflict is directly harming user outcomes or business metrics, and you have evidence
- You've attempted direct resolution at least twice with no movement
- The decision is irreversible if you wait
- Your manager is aware and supports escalation

"I want to let you know I'm planning to raise this with [person] because [reason]. I wanted you to hear it from me first."

### When to Stop Fighting and Execute

- You've made your case clearly once (twice maximum)
- The decision-maker has heard you and still disagrees
- The stakes are real but not catastrophic

Then: execute the decision fully and well. Your disagreement is on record. Half-hearted execution is worse than losing the argument.

### When the Environment Is the Problem

Persistent patterns that signal a systemic issue, not a person issue:

- You're regularly undermined after making decisions
- Good-faith escalations are penalized
- Credit redistribution is structural and protected
- Your judgment is questioned without evidence

At this point, the playbook doesn't help. The question becomes: is this fixable, and am I the person to fix it?

---

## Section 7 — The Bidirectional Lens (When You ARE the Exec)

For Directors, VPs, and CPOs: the same dynamics look different from the other side of the table. Your PMs are running these plays on you — and they should be. Here's how to receive influence well, and how to recognize when the system is failing.

### Recognizing Plays Being Run on You

| What your PM is doing | The play they're running | What it means |
|----------------------|-------------------------|---------------|
| Asking you to choose what to cut | Play 1 (Trade-Off) | They're protecting their team. Good sign. |
| Acknowledging your idea then pivoting to data | Play 2 (Redirect) | They think you're wrong but respect you. Let them show the data. |
| Scheduling 1:1s before a group review | Play 3 (Pre-Wire) | They're doing their job well. Reward this behavior. |
| Over-sharing status updates you didn't ask for | Play 4 (Transparency) | They sense a trust deficit. Ask yourself if you caused it. |
| Requesting a meeting with you and another exec | Play 6 (Dual-Exec) | They're stuck between conflicting demands. This is your problem to solve, not theirs. |
| Bringing bad news with options | Play 7 (Bad News) | They're being direct. Don't punish this or you'll never hear bad news early again. |
| Saying no with a trade-off frame | Play 8 (Principled No) | This is a sign of judgment, not insubordination. |
| Asking to reopen a decision with new data | Play 9 (Reversal) | They have conviction. Hear them out fully before deciding. |

### Your Failure Modes as the Exec

**You're the Bottleneck.** If every decision routes through you, your PMs can't move. Diagnostic: count how many decisions are waiting on you right now. If it's more than 3, you're the problem.

**You're Punishing Bad News.** If your PMs soften bad news, delay it, or bury it in status updates, they've learned that directness isn't safe. Fix: the next time someone brings you bad news, explicitly thank them for the speed of delivery before discussing the problem.

**You're Creating the Misalignment.** If your PMs keep getting stuck between conflicting exec asks (Play 6), the strategy isn't clear enough at your level. Fix: write down the priority stack. If you can't rank your top 3 bets, your team can't either.

**You're Not Letting Them Say No.** If your PMs say yes to everything you ask, you either have a team of pushovers or a culture where saying no feels unsafe. Test: next time you make a request, explicitly say "Push back if this doesn't make sense against your current priorities."

**You're the Credit Absorber.** Check: when you present to the board or your CEO, do you name the PM who led the work? If not, you're eroding their visibility whether you intend to or not. Fix: "This was led by [PM name] — I'll let them walk you through it."

---

## Section 8 — Routing Matrix

Use this to quickly navigate from your situation to the right play(s).

### By Career Stage × Situation

| PM Level | Most Common Situation | Start Here | Then Add |
|----------|----------------------|------------|----------|
| Jr PM | Being ignored, scope expanding | Play 1 (Trade-off) | Play 7 (Bad news) |
| PM | Roadmap blocked, trust deficit | Play 3 (Pre-wiring) | Play 4 (Transparency) |
| Senior PM | Solution-first exec, competing stakeholders | Play 2 (Redirect) | Play 6 (Dual-exec) |
| Staff / Principal PM | Decision reversals, credit erosion, peer deadlocks | Play 5 (Visibility) + Play 10 (Peer Negotiation) | Play 9 (Reversal) |
| Director / VP | Team's conflicts becoming yours | Play 3 + Play 6 at scale | Section 7 (Bidirectional) |
| CPO | Board misalignment, CEO dynamic | Plays 7, 8, 9 | Section 6 (Exit criteria) + Section 7 |

### By Archetype × Play

| Archetype | Primary Play | Secondary Play | Avoid |
|-----------|-------------|----------------|-------|
| Scope Creeper | Play 1 (Trade-off) | Play 8 (Principled No) | Flat refusal |
| Solution-First Thinker | Play 2 (Redirect) | Play 3 (Pre-wire) | Walking them through frameworks |
| Trust Withholder | Play 4 (Transparency) | Play 7 (Bad News — speed builds trust) | Defending methodology |
| Invisible Decision Maker | Play 3 (Pre-wire) | Play 6 (Dual-exec to surface them) | Public confrontation |
| Credit Absorber | Play 5 (Visibility) | — | Direct confrontation |
| Scope Blocker | Play 8 (Principled No) | Play 3 (Pre-wire) | Making them look bad |
| Chaos Agent | Play 3 (Pre-wire) + written confirmation | Play 1 (Trade-off to lock scope) | Ambiguity |
| Brilliant Jerk | Play 9 (Reversal — bring data and conviction) | Play 2 (Redirect — fast, not soft) | Hedging language |

---

## Chained Workflows

### Full Influence Sequence
Situation diagnosis (Section 1) → Archetype identification (Section 2) → Objective clarification (Section 3) → Play selection (Section 4) → Counter preparation (Section 5) → Execute → Written follow-up documenting decisions and next steps

### Pre-Meeting Preparation
Situation diagnosis → Identify veto holders → Pre-wire 1:1s (Play 3) → Counter-prep (Section 5) → Meeting → Written summary to attendees within 24 hours

### Trust Rebuilding (4-Week Cadence)
Trust-deficit diagnosis (S5) → Week 1-4: Transparency offensive (Play 4) via weekly 5-bullet update → Use Bad News Protocol (Play 7) at first opportunity to prove directness → Continue weekly cadence until trust signals shift
